# Dear — A Letter Writing Room

A small, private website for writing the letters people put off: confessions,
apologies, thank-yous, love letters, goodbyes, and letters of forgiveness.
Pick who it's for, get an editable starting draft, rewrite it until it sounds
like you, seal it, and send it however you like.

No account, no backend, no build step. It's plain HTML, CSS, and
JavaScript — open `index.html` in a browser and it works.

---

## Features

- **To / From fields** you control directly — no forced usernames.
- **Auto-draft** — pick a category (confession, apology, gratitude, love,
  goodbye, forgiveness) and a tone (heartfelt, poetic, brief, formal) and get
  a starting paragraph to react to. It is explicitly framed as a draft, not a
  finished letter — the whole point is that you rewrite it.
- **Fully editable paper** — the letter body is a live, formattable text
  field (bold, italic, underline, bulleted list) with a running word count.
- **Seal & keep** — sealed letters are added to a mailbox for the current
  session, shown as postmarked cards you can reopen, re-edit, or delete.
- **Recorded responses** — attach the reply you actually got back to any
  kept letter, with an optional note on how or when it arrived.
- **Copy, download, print, or share** any letter — as plain text, a `.txt`
  file, a print-ready page (Save as PDF), or through the device's native
  share sheet, email, or SMS. Nothing posts anywhere on its own.
- **Export / import the whole mailbox** as a single `.json` file, so you can
  back it up or move it between browsers.

## Project structure

```
confession-letters/
├── index.html          Page structure and markup
├── css/
│   └── style.css        All styling (ink/paper/wax-seal design system)
├── js/
│   └── app.js            All behavior (templates, composer, mailbox, modals)
└── README.md
```

Everything is self-contained in these three source files — there is no
package.json, no bundler, and no build step to run.

## Running it locally

Because the page uses `fetch`-free, dependency-free JavaScript, you can just
open the file directly:

```bash
open index.html          # macOS
xdg-open index.html      # Linux
start index.html         # Windows
```

If your browser blocks any local-file behavior, serve it instead:

```bash
python3 -m http.server 8080
# then visit http://localhost:8080
```

## Deploying it (GitHub Pages)

1. Push this folder to a new GitHub repository.
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`,
   pick the `main` branch and the `/ (root)` folder, then save.
4. GitHub will publish the site at
   `https://<your-username>.github.io/<repo-name>/` within a minute or two.

No other configuration is needed — the site has no server-side code.

## Making letters persist across visits

By default, sealed letters are kept **only for the current browser tab** —
refreshing the page clears the mailbox. This is deliberate: it keeps the app
safe to preview anywhere without silently depending on storage a preview
environment might not keep.

Once you've deployed your own copy, you can make the mailbox persist by
switching to `localStorage`:

1. Open `js/app.js` and find the section headed `STORAGE ADAPTER`.
2. Comment out (or delete) the in-memory adapter.
3. Uncomment the `localStorageAdapter` block directly below it.
4. Redeploy. Letters will now survive page reloads on the same browser and
   device.

If you'd rather every visitor share the same mailbox (e.g. a two-person
private site), you'll want a small backend or a hosted database (Firebase,
Supabase, a simple key-value API, etc.) instead of `localStorage`, which is
per-browser only.

## Customizing

- **Add or edit templates**: open `js/app.js` and edit the `TEMPLATES`
  object near the top. Each category has four tones; add a new tone key to
  any category, or a whole new category (and add a matching `<option>` to
  the `#fieldCategory` select in `index.html`, plus an entry in
  `CATEGORY_LABEL` and `SIGNOFF_BY_CATEGORY`).
- **Change the palette or type**: all design tokens are CSS custom
  properties at the top of `css/style.css` under `:root`.
- **Change the sign-off line per category**: edit `SIGNOFF_BY_CATEGORY` in
  `js/app.js`.

## Privacy

This is a static, client-side page. There is no server component in this
repository, no analytics, and no network calls other than loading the
Google Fonts used for typography. Whatever you write stays in your browser
tab unless you explicitly copy, download, print, share, or export it.

## License

MIT — see [`LICENSE`](./LICENSE). Use it, fork it, rewrite the templates
entirely; a credit link back is appreciated but not required.
