/*!
 * Dear — A Letter Writing Room
 * ---------------------------------------------------------------------------
 * Vanilla JS, no build step, no dependencies. Everything lives in this file:
 *   1. Template data (auto-draft starting points per category + tone)
 *   2. Composer logic (fields, auto-write, formatting, word count)
 *   3. Sealing letters into an in-memory "mailbox" for this session
 *   4. Ledger rendering (list of kept letters, open/edit/delete)
 *   5. Recorded responses (attach a reply to a kept letter)
 *   6. Export / import of the whole mailbox as JSON
 *   7. Copy / download / print / share of a single letter
 *   8. Small utilities (toast, date formatting, escaping)
 *
 * PERSISTENCE NOTE
 * -----------------------------------------------------------------------
 * This build keeps the mailbox in memory for the current browser tab only,
 * by design — it keeps the app safe to preview anywhere, including inside
 * an embedded/sandboxed viewer, without silently depending on browser
 * storage that such a viewer may not persist.
 *
 * Once you've deployed your own copy (GitHub Pages, Netlify, your own
 * server, etc.) you can make the mailbox persist across visits by swapping
 * the four functions in the "STORAGE ADAPTER" section below for versions
 * backed by localStorage. A ready-to-use version is included there,
 * commented out — just uncomment it and comment out the in-memory version
 * directly above it. See the README for the full walkthrough.
 * ---------------------------------------------------------------------------
 */

(function () {
  "use strict";

  /* ============================================================
     1. TEMPLATE DATA
     Each category has four tones. {to}, {from}, {detail} are filled
     in from the composer fields at draft time. {detail} gracefully
     drops its sentence if the field was left blank.
     ============================================================ */

  const TEMPLATES = {
    confession: {
      heartfelt: `There's something I should have told you a long time ago, and I keep finding reasons to put it off, so I'm just going to write it instead. {detailSentence}I've been carrying this around quietly, and it's gotten heavier the longer I've kept it to myself. I don't need you to fix anything or say the right thing back — I just needed it to exist outside my own head for once, and you're the person it belongs to.`,
      poetic: `I have practiced this sentence in the shower, in the car, in the five minutes before falling asleep, and it never comes out the way I mean it. {detailSentence}So I'm putting it on paper instead, where it can sit still long enough to be read properly. Some truths are too big to say out loud on the first try; this is my second, quieter try.`,
      brief: `I need to tell you something I've been sitting on. {detailSentence}I should have said this sooner, but I'm saying it now: this has been on my mind, and you deserve to know it rather than sense it.`,
      formal: `I am writing to share something I have not yet found the right moment to say in person. {detailSentence}I have thought carefully about how to put this, and I trust that reading it in my own words will make my intentions clearer than I could manage aloud.`,
    },
    apology: {
      heartfelt: `I keep replaying what happened, and I want to say clearly, without excuses attached: I'm sorry. {detailSentence}I understand if it takes time before this feels like enough, and I'm not asking you to say it's fine — I just needed you to know that I see what I did, and I regret it.`,
      poetic: `Some apologies arrive too late to undo anything, and I think this might be one of those, but I'd rather say it late than not at all. {detailSentence}I am sorry for the version of me that let this happen, and grateful, still, for whatever room you're willing to leave for me.`,
      brief: `I was wrong, and I'm sorry. {detailSentence}I'm not going to make excuses for it — I just wanted you to hear it plainly, from me, in writing, so there's no mistaking it.`,
      formal: `I want to formally acknowledge that I was in the wrong, and to offer my sincere apology. {detailSentence}I take responsibility for what happened and for the effect it had on you, and I hope, in time, to show through my actions that this apology was meant seriously.`,
    },
    gratitude: {
      heartfelt: `I don't think I've ever properly thanked you for what you've meant to me, so I'm doing it now, in writing, so it counts. {detailSentence}You showed up in ways that were easy to take for granted at the time and impossible to forget since. Thank you — genuinely, and later than you deserved to hear it.`,
      poetic: `Gratitude is a strange thing to delay, and yet I have, for longer than I'd like to admit. {detailSentence}You were a kind of quiet weather in my life — steady, present, easy to stop noticing precisely because you were always there. I noticed. I still do.`,
      brief: `Thank you. {detailSentence}I don't say it enough, so here it is, plainly: I noticed everything you did, and it mattered.`,
      formal: `I wanted to formally express my gratitude for the support you have shown me. {detailSentence}Your contribution has not gone unnoticed, and I wanted this to be on record, in my own words, rather than left unsaid.`,
    },
    love: {
      heartfelt: `I've talked myself out of saying this more times than I can count, so I'm writing it down instead, where I can't take it back halfway through. {detailSentence}I love you — plainly, and without the qualifiers I usually attach to make it feel safer to say. I wanted you to have it in writing, so it's harder for either of us to pretend I didn't mean it.`,
      poetic: `There is a version of this letter I've written a dozen times in my head, always better than this one, always unsent. {detailSentence}What I mean, underneath all of it, is simple: I love you, in the unglamorous, everyday way that turns out to be the realest kind. I wanted that written down somewhere permanent.`,
      brief: `I love you. {detailSentence}I wanted to say it in a way you could keep, not just hear once and let pass.`,
      formal: `I am writing to tell you, plainly and without embellishment, that I love you. {detailSentence}I recognize this may not be how you expected to hear it, but I wanted to say it in a form you could return to, rather than only in a passing moment.`,
    },
    goodbye: {
      heartfelt: `I've thought a lot about how to close this chapter, and I don't think there's a way to do it that doesn't feel a little unfinished. {detailSentence}I'm grateful for what we had, even the parts that ended up hard, and I wanted to leave things with words instead of silence. Take care of yourself — I mean that completely.`,
      poetic: `Some things end with a door closing and some end with a light slowly dimming, and this has felt like the second kind. {detailSentence}I wanted to mark the ending properly, in writing, rather than let it drift into just — stopping. Thank you for the time this took up in my life; it was not wasted.`,
      brief: `This is my way of saying goodbye properly instead of just letting things fade. {detailSentence}I wanted you to have something written, not just an absence where I used to be.`,
      formal: `I am writing to formally close this chapter between us. {detailSentence}I wanted to mark the ending with intention rather than allow it to end without acknowledgment, and I wish you well as we each move forward.`,
    },
    forgiveness: {
      heartfelt: `I've been holding onto something for a long time, and I think I'm finally ready to put it down. {detailSentence}I forgive you — not because what happened was fine, but because I don't want to keep carrying it. I wanted you to know that, in case it's been sitting on you too.`,
      poetic: `Anger is heavy to carry for as long as I have, and I'm tired, in the specific way that comes from holding onto something past its useful life. {detailSentence}So: I forgive you. Not for your sake alone, but for mine too — I'd like my hands free of it.`,
      brief: `I forgive you. {detailSentence}I wanted to say it plainly, in writing, so it's clear and doesn't get lost.`,
      formal: `I am writing to let you know that I have decided to forgive what happened between us. {detailSentence}I wanted to state this clearly and in a lasting form, so there is no ambiguity about where I stand.`,
    },
  };

  const CATEGORY_LABEL = {
    confession: "Confession",
    apology: "Apology",
    gratitude: "Gratitude",
    love: "Love",
    goodbye: "Goodbye",
    forgiveness: "Forgiveness",
  };

  const SIGNOFF_BY_CATEGORY = {
    confession: "With everything I mean by it,",
    apology: "With real regret,",
    gratitude: "With more thanks than this page can hold,",
    love: "Always,",
    goodbye: "Wishing you well, truly,",
    forgiveness: "Free of it, finally,",
  };

  /* ============================================================
     2. DOM REFERENCES
     ============================================================ */

  const el = (id) => document.getElementById(id);

  const fieldTo = el("fieldTo");
  const fieldFrom = el("fieldFrom");
  const fieldCategory = el("fieldCategory");
  const fieldTone = el("fieldTone");
  const fieldOccasion = el("fieldOccasion");

  const btnAutoWrite = el("btnAutoWrite");
  const btnClear = el("btnClear");
  const btnSeal = el("btnSeal");
  const btnCopy = el("btnCopy");
  const btnDownloadTxt = el("btnDownloadTxt");
  const btnPrint = el("btnPrint");
  const btnShare = el("btnShare");
  const btnExportAll = el("btnExportAll");
  const btnImportAll = el("btnImportAll");
  const fileImport = el("fileImport");

  const paperSalutation = el("paperTo");
  const paperBody = el("paperBody");
  const paperFrom = el("paperFrom");
  const paperSignoff = document.querySelector(".paper__signoff");
  const paperDate = el("paperDate");
  const wordCountEl = el("wordCount");
  const composerStatus = el("composerStatus");

  const ledgerList = el("ledgerList");
  const ledgerEmpty = el("ledgerEmpty");
  const ledgerCount = el("ledgerCount");

  const responseBackdrop = el("responseBackdrop");
  const responseText = el("responseText");
  const responseMeta = el("responseMeta");
  const responseClose = el("responseClose");
  const responseCancel = el("responseCancel");
  const responseSave = el("responseSave");

  const shareBackdrop = el("shareBackdrop");
  const shareClose = el("shareClose");
  const shareSystem = el("shareSystem");
  const shareEmail = el("shareEmail");
  const shareSms = el("shareSms");
  const shareClipboard = el("shareClipboard");

  const toastEl = el("toast");

  let activeResponseId = null; // which letter the response modal is editing
  let activeShareLetter = null; // {to, from, body, subject} snapshot for the share modal

  /* ============================================================
     3. STORAGE ADAPTER  (in-memory by default — see note at top)
     ============================================================ */

  const store = (function inMemoryAdapter() {
    let mailbox = [];
    return {
      all() { return mailbox.slice(); },
      save(letter) { mailbox.unshift(letter); },
      update(id, patch) {
        mailbox = mailbox.map((l) => (l.id === id ? Object.assign({}, l, patch) : l));
      },
      remove(id) { mailbox = mailbox.filter((l) => l.id !== id); },
      replaceAll(list) { mailbox = list.slice(); },
    };
  })();

  /*
   * ---- OPTIONAL: persistent localStorage adapter -----------------------
   * Uncomment this block and delete/comment the in-memory adapter above
   * to make the mailbox survive page reloads once you've deployed your
   * own copy of this site (e.g. on GitHub Pages).
   *
   * const STORAGE_KEY = "dear-mailbox-v1";
   * const store = (function localStorageAdapter() {
   *   function read() {
   *     try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
   *     catch (e) { return []; }
   *   }
   *   function write(list) { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); }
   *   return {
   *     all() { return read(); },
   *     save(letter) { const list = read(); list.unshift(letter); write(list); },
   *     update(id, patch) {
   *       write(read().map((l) => (l.id === id ? Object.assign({}, l, patch) : l)));
   *     },
   *     remove(id) { write(read().filter((l) => l.id !== id)); },
   *     replaceAll(list) { write(list); },
   *   };
   * })();
   * ------------------------------------------------------------------- */

  /* ============================================================
     4. UTILITIES
     ============================================================ */

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function plainTextFromHtml(html) {
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    return tmp.textContent.replace(/\n{3,}/g, "\n\n").trim();
  }

  function wordCount(text) {
    const trimmed = text.trim();
    if (!trimmed) return 0;
    return trimmed.split(/\s+/).length;
  }

  function formatDate(d) {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
  }

  let toastTimer = null;
  function toast(message) {
    toastEl.textContent = message;
    toastEl.setAttribute("data-show", "");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.removeAttribute("data-show"), 2600);
  }

  function uid() {
    return "L" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function setStatus(message) {
    composerStatus.textContent = message;
    if (message) setTimeout(() => { if (composerStatus.textContent === message) composerStatus.textContent = ""; }, 3200);
  }

  /* ============================================================
     5. COMPOSER
     ============================================================ */

  function currentDisplayTo() { return fieldTo.value.trim() || "\u2014"; }
  function currentDisplayFrom() { return fieldFrom.value.trim() || "\u2014"; }

  function syncSalutationAndSignature() {
    paperSalutation.textContent = currentDisplayTo();
    paperFrom.textContent = currentDisplayFrom();
    const category = fieldCategory.value;
    paperSignoff.textContent = SIGNOFF_BY_CATEGORY[category] || "With everything I mean by it,";
  }

  function updateWordCount() {
    const text = paperBody.innerText || "";
    const n = wordCount(text);
    wordCountEl.textContent = `${n} word${n === 1 ? "" : "s"}`;
  }

  function buildDraftParagraph() {
    const category = fieldCategory.value;
    const tone = fieldTone.value;
    const detail = fieldOccasion.value.trim();
    const template = (TEMPLATES[category] && TEMPLATES[category][tone]) || TEMPLATES.confession.heartfelt;

    const detailSentence = detail
      ? `Especially thinking about ${detail}. `
      : "";

    return template.replace("{detailSentence}", detailSentence);
  }

  function autoWrite() {
    const paragraph = buildDraftParagraph();
    paperBody.innerText = paragraph;
    syncSalutationAndSignature();
    updateWordCount();
    stampPostmark();
    setStatus("Draft added — now make it yours.");
    paperBody.focus();
    placeCursorAtEnd(paperBody);
  }

  function placeCursorAtEnd(node) {
    const range = document.createRange();
    range.selectNodeContents(node);
    range.collapse(false);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function clearLetter() {
    paperBody.innerHTML = "";
    updateWordCount();
    setStatus("Cleared.");
    paperBody.focus();
  }

  function stampPostmark() {
    paperDate.textContent = formatDate(new Date()).toUpperCase();
  }

  function currentLetterSnapshot() {
    return {
      to: fieldTo.value.trim(),
      from: fieldFrom.value.trim(),
      category: fieldCategory.value,
      tone: fieldTone.value,
      bodyHtml: paperBody.innerHTML,
      bodyText: plainTextFromHtml(paperBody.innerHTML),
    };
  }

  function letterFullText(snapshot) {
    const to = snapshot.to || "\u2014";
    const from = snapshot.from || "\u2014";
    const signoff = SIGNOFF_BY_CATEGORY[snapshot.category] || "With everything I mean by it,";
    return `Dear ${to},\n\n${snapshot.bodyText}\n\n${signoff}\n${from}`;
  }

  /* --- formatting toolbar (contenteditable) --- */
  document.querySelectorAll(".tbtn[data-cmd]").forEach((btn) => {
    btn.addEventListener("click", () => {
      paperBody.focus();
      document.execCommand(btn.getAttribute("data-cmd"), false, null);
      updateWordCount();
    });
  });

  /* ============================================================
     6. SEAL A LETTER (add to mailbox)
     ============================================================ */

  function sealLetter() {
    const snapshot = currentLetterSnapshot();
    if (!snapshot.bodyText) {
      setStatus("Write something before sealing it.");
      paperBody.focus();
      return;
    }
    stampPostmark();
    const letter = {
      id: uid(),
      to: snapshot.to,
      from: snapshot.from,
      category: snapshot.category,
      tone: snapshot.tone,
      bodyHtml: snapshot.bodyHtml,
      bodyText: snapshot.bodyText,
      createdAt: new Date().toISOString(),
      response: null,
    };
    store.save(letter);
    renderLedger();
    setStatus("Sealed and kept in your mailbox below.");
    toast("Letter sealed \u2014 find it in Kept Letters.");
    document.getElementById("ledger").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* ============================================================
     7. LEDGER RENDERING
     ============================================================ */

  function renderLedger() {
    const letters = store.all();
    ledgerCount.textContent = `${letters.length} letter${letters.length === 1 ? "" : "s"} kept`;

    if (letters.length === 0) {
      ledgerEmpty.removeAttribute("data-hidden");
      ledgerList.innerHTML = "";
      return;
    }
    ledgerEmpty.setAttribute("data-hidden", "");

    ledgerList.innerHTML = letters.map(letterCardHtml).join("");

    letters.forEach((letter) => {
      const card = ledgerList.querySelector(`[data-id="${letter.id}"]`);
      if (!card) return;
      card.querySelector('[data-action="open"]').addEventListener("click", () => openLetterInComposer(letter.id));
      card.querySelector('[data-action="response"]').addEventListener("click", () => openResponseModal(letter.id));
      card.querySelector('[data-action="delete"]').addEventListener("click", () => deleteLetter(letter.id));
      card.querySelector('[data-action="copy"]').addEventListener("click", () => copyLetterById(letter.id));
    });
  }

  function letterCardHtml(letter) {
    const dateLabel = formatDate(new Date(letter.createdAt));
    const responseBlock = letter.response
      ? `<p class="letter-card__response">&ldquo;${escapeHtml(truncate(letter.response.text, 140))}&rdquo;${letter.response.meta ? ` &mdash; ${escapeHtml(letter.response.meta)}` : ""}</p>`
      : "";
    return `
      <li class="letter-card" data-id="${letter.id}">
        <div class="letter-card__stamp" aria-hidden="true"></div>
        <p class="letter-card__meta">${CATEGORY_LABEL[letter.category] || "Letter"} &middot; ${dateLabel}</p>
        <p class="letter-card__title">To ${escapeHtml(letter.to || "\u2014")}</p>
        <p class="letter-card__excerpt">${escapeHtml(truncate(letter.bodyText, 180))}</p>
        ${responseBlock}
        <div class="letter-card__actions">
          <button type="button" data-action="open">Open &amp; edit</button>
          <button type="button" data-action="response">${letter.response ? "Edit response" : "Record response"}</button>
          <button type="button" data-action="copy">Copy</button>
          <button type="button" data-action="delete">Delete</button>
        </div>
      </li>`;
  }

  function truncate(text, max) {
    if (text.length <= max) return text;
    return text.slice(0, max).replace(/\s+\S*$/, "") + "\u2026";
  }

  function openLetterInComposer(id) {
    const letter = store.all().find((l) => l.id === id);
    if (!letter) return;
    fieldTo.value = letter.to;
    fieldFrom.value = letter.from;
    fieldCategory.value = letter.category;
    fieldTone.value = letter.tone;
    paperBody.innerHTML = letter.bodyHtml;
    syncSalutationAndSignature();
    updateWordCount();
    stampPostmark();
    setStatus("Loaded back into the composer \u2014 sealing again will keep it as a new copy.");
    document.getElementById("composer").scrollIntoView({ behavior: "smooth", block: "start" });
    paperBody.focus();
  }

  function deleteLetter(id) {
    store.remove(id);
    renderLedger();
    toast("Letter removed from the mailbox.");
  }

  function copyLetterById(id) {
    const letter = store.all().find((l) => l.id === id);
    if (!letter) return;
    const text = letterFullText({
      to: letter.to, from: letter.from, category: letter.category, bodyText: letter.bodyText,
    });
    copyToClipboard(text);
  }

  /* ============================================================
     8. RECORDED RESPONSES
     ============================================================ */

  function openResponseModal(id) {
    const letter = store.all().find((l) => l.id === id);
    if (!letter) return;
    activeResponseId = id;
    responseText.value = letter.response ? letter.response.text : "";
    responseMeta.value = letter.response ? letter.response.meta || "" : "";
    showModal(responseBackdrop);
    responseText.focus();
  }

  function saveResponse() {
    if (!activeResponseId) return;
    const text = responseText.value.trim();
    const meta = responseMeta.value.trim();
    store.update(activeResponseId, { response: text ? { text, meta, recordedAt: new Date().toISOString() } : null });
    renderLedger();
    hideModal(responseBackdrop);
    toast(text ? "Response recorded." : "Response cleared.");
    activeResponseId = null;
  }

  /* ============================================================
     9. EXPORT / IMPORT MAILBOX
     ============================================================ */

  function exportMailbox() {
    const letters = store.all();
    if (letters.length === 0) {
      toast("Nothing to export yet.");
      return;
    }
    const payload = {
      exportedAt: new Date().toISOString(),
      app: "dear-letter-writing-room",
      version: 1,
      letters,
    };
    downloadFile(`dear-mailbox-${dateSlug()}.json`, JSON.stringify(payload, null, 2), "application/json");
    toast("Mailbox exported.");
  }

  function importMailbox(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        const letters = Array.isArray(parsed) ? parsed : parsed.letters;
        if (!Array.isArray(letters)) throw new Error("Unrecognized file shape");
        const existingIds = new Set(store.all().map((l) => l.id));
        letters.forEach((l) => {
          if (!l.id || existingIds.has(l.id)) l.id = uid();
          store.save(l);
        });
        renderLedger();
        toast(`Imported ${letters.length} letter${letters.length === 1 ? "" : "s"}.`);
      } catch (err) {
        toast("That file didn't look like a mailbox export.");
      }
    };
    reader.readAsText(file);
  }

  function dateSlug() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }

  /* ============================================================
     10. COPY / DOWNLOAD / PRINT / SHARE (single letter)
     ============================================================ */

  function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        () => toast("Copied to clipboard."),
        () => fallbackCopy(text)
      );
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); toast("Copied to clipboard."); }
    catch (e) { toast("Couldn't copy automatically \u2014 select the text manually."); }
    document.body.removeChild(ta);
  }

  function downloadFile(filename, content, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function downloadCurrentAsTxt() {
    const snapshot = currentLetterSnapshot();
    if (!snapshot.bodyText) { toast("Write something first."); return; }
    downloadFile(`letter-${dateSlug()}.txt`, letterFullText(snapshot), "text/plain");
    toast("Downloaded as .txt");
  }

  function copyCurrent() {
    const snapshot = currentLetterSnapshot();
    if (!snapshot.bodyText) { toast("Write something first."); return; }
    copyToClipboard(letterFullText(snapshot));
  }

  function printCurrent() {
    const snapshot = currentLetterSnapshot();
    if (!snapshot.bodyText) { toast("Write something first."); return; }
    window.print();
  }

  function openShareModal() {
    const snapshot = currentLetterSnapshot();
    if (!snapshot.bodyText) { toast("Write something first."); return; }
    activeShareLetter = snapshot;
    const text = letterFullText(snapshot);
    const subject = `A letter for ${snapshot.to || "you"}`;
    shareEmail.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
    shareSms.href = `sms:?&body=${encodeURIComponent(text)}`;
    showModal(shareBackdrop);
  }

  function shareViaSystem() {
    if (!activeShareLetter) return;
    const text = letterFullText(activeShareLetter);
    if (navigator.share) {
      navigator.share({ title: `A letter for ${activeShareLetter.to || "you"}`, text }).catch(() => {});
    } else {
      copyToClipboard(text);
      toast("Your device doesn't support direct sharing \u2014 copied instead.");
    }
  }

  /* ============================================================
     11. MODAL HELPERS
     ============================================================ */

  function showModal(node) {
    node.removeAttribute("hidden");
    document.body.style.overflow = "hidden";
  }
  function hideModal(node) {
    node.setAttribute("hidden", "");
    document.body.style.overflow = "";
  }

  [responseBackdrop, shareBackdrop].forEach((backdrop) => {
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) hideModal(backdrop);
    });
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (!responseBackdrop.hasAttribute("hidden")) hideModal(responseBackdrop);
      if (!shareBackdrop.hasAttribute("hidden")) hideModal(shareBackdrop);
    }
  });

  /* ============================================================
     12. EVENT WIRING
     ============================================================ */

  fieldTo.addEventListener("input", syncSalutationAndSignature);
  fieldFrom.addEventListener("input", syncSalutationAndSignature);
  fieldCategory.addEventListener("change", syncSalutationAndSignature);
  paperBody.addEventListener("input", updateWordCount);

  btnAutoWrite.addEventListener("click", autoWrite);
  btnClear.addEventListener("click", clearLetter);
  btnSeal.addEventListener("click", sealLetter);
  btnCopy.addEventListener("click", copyCurrent);
  btnDownloadTxt.addEventListener("click", downloadCurrentAsTxt);
  btnPrint.addEventListener("click", printCurrent);
  btnShare.addEventListener("click", openShareModal);

  btnExportAll.addEventListener("click", exportMailbox);
  btnImportAll.addEventListener("click", () => fileImport.click());
  fileImport.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) importMailbox(file);
    fileImport.value = "";
  });

  responseClose.addEventListener("click", () => hideModal(responseBackdrop));
  responseCancel.addEventListener("click", () => hideModal(responseBackdrop));
  responseSave.addEventListener("click", saveResponse);

  shareClose.addEventListener("click", () => hideModal(shareBackdrop));
  shareSystem.addEventListener("click", shareViaSystem);
  shareClipboard.addEventListener("click", () => {
    if (activeShareLetter) copyToClipboard(letterFullText(activeShareLetter));
  });

  /* ============================================================
     13. INIT
     ============================================================ */

  function init() {
    syncSalutationAndSignature();
    updateWordCount();
    stampPostmark();
    renderLedger();
    const yearEl = el("year");
    if (yearEl) yearEl.textContent = new Date().getFullYear();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
